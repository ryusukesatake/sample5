class ComentsController < ApplicationController
end
