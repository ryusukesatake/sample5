class HelloController < ApplicationController
    def index
    end

    def link
    end
end
