class TweetsController < ApplicationController
    def index
      
        if params[:search] == nil
        @tweets = Tweet.all
      elsif params[:search] == ''
        @tweets= Tweet.all
      else
        #部分検索
        @tweets = Tweet.where("body LIKE ? ",'%' + params[:search] + '%')
      end
    end

    before_action :authenticate_user!

    def new
        @tweet = Tweet.new
    end

    def create
      @tweet = Tweet.new(tweet_params)
      @tweet.user_id = current_user.id
      if @tweet.save and @tweet.genre == 1
          redirect_to :action => "page1"
      elsif @tweet.save and @tweet.genre == 2
          redirect_to :action => "page2"
      elsif @tweet.save and @tweet.genre == 3
          redirect_to :action => "page3"
      elsif @tweet.save and @tweet.genre == 4
          redirect_to :action => "page4"
      else
          redirect_to :action => "index"
      end
  end
    
      def show
        @tweet = Tweet.find(params[:id])
        @comments = @tweet.comments
        @comment = Comment.new
      end

      def edit
        @tweet = Tweet.find(params[:id])
      end

      def update
        tweet = Tweet.find(params[:id])
        if tweet.update(tweet_params)
          redirect_to :action => "show", :id => tweet.id
        else
          redirect_to :action => "new"
        end
      end

      def destroy
        tweet = Tweet.find(params[:id])
        tweet.destroy
        redirect_to action: :index
      end

      def page1
      @tweet1 = Tweet.where(genre: 1)
      end
      def page2
      @tweet2 = Tweet.where(genre: 2)
      end
      def page3
      @tweet3 = Tweet.where(genre: 3)
      end
      def page4
      @tweet4 = Tweet.where(genre: 4)
      end



      private
      def tweet_params
        params.require(:tweet).permit(:body, :image, :genre, tag_ids: [])
      end
end
