Rails.application.routes.draw do
  devise_for :users
  resources :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  get 'hello/index' => 'hello#index'
  get 'hello/link' => 'hello#link'
  get 'tweets/page1' => 'tweets#page1'
  get 'tweets/page2' => 'tweets#page2'
  get 'tweets/page3' => 'tweets#page3'
  get 'tweets/page4' => 'tweets#page4'
  
  resources :tweets do
    resources :likes, only: [:create, :destroy]
  end
  
  
  
  
root 'hello#index'

end
